package com.notdefteri.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController

class MainActivity : ComponentActivity() {

    private val viewModel: NoteViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            NotDefteriTheme {
                Surface(modifier = Modifier) {
                    NotDefteriApp(viewModel)
                }
            }
        }
    }
}

@Composable
fun NotDefteriApp(viewModel: NoteViewModel) {
    val navController: NavHostController = rememberNavController()

    NavHost(navController = navController, startDestination = "list") {
        composable("list") {
            NoteListScreen(
                viewModel = viewModel,
                onNoteClick = { id -> navController.navigate("edit/$id") },
                onAddNoteClick = { navController.navigate("edit/0") }
            )
        }
        composable("edit/{noteId}") { backStackEntry ->
            val noteId = backStackEntry.arguments?.getString("noteId")?.toLongOrNull() ?: 0L
            NoteEditScreen(
                viewModel = viewModel,
                noteId = noteId,
                onBack = { navController.popBackStack() }
            )
        }
    }
}

@Composable
fun NotDefteriTheme(content: @Composable () -> Unit) {
    val colors = if (isSystemInDarkTheme()) {
        darkColorScheme(primary = androidx.compose.ui.graphics.Color(0xFFB74D00))
    } else {
        lightColorScheme(primary = androidx.compose.ui.graphics.Color(0xFFB74D00))
    }
    MaterialTheme(colorScheme = colors, content = content)
}
