package com.notdefteri.app

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.notdefteri.app.data.Note
import com.notdefteri.app.data.NoteDatabase
import com.notdefteri.app.data.NoteRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class NoteViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: NoteRepository

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery

    val notes: StateFlow<List<Note>>

    init {
        val dao = NoteDatabase.getDatabase(application).noteDao()
        repository = NoteRepository(dao)

        notes = _searchQuery.flatMapLatest { query ->
            if (query.isBlank()) repository.getAllNotes()
            else repository.searchNotes(query)
        }.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )
    }

    fun onSearchQueryChange(query: String) {
        _searchQuery.value = query
    }

    suspend fun getNoteById(id: Long): Note? = repository.getNoteById(id)

    fun saveNote(id: Long, title: String, content: String, onSaved: (Long) -> Unit = {}) {
        viewModelScope.launch {
            val now = System.currentTimeMillis()
            if (id == 0L) {
                val newId = repository.saveNote(
                    Note(title = title, content = content, createdAt = now, updatedAt = now)
                )
                onSaved(newId)
            } else {
                val existing = repository.getNoteById(id)
                if (existing != null) {
                    repository.updateNote(existing.copy(title = title, content = content, updatedAt = now))
                }
                onSaved(id)
            }
        }
    }

    fun deleteNote(note: Note) {
        viewModelScope.launch {
            repository.deleteNote(note)
        }
    }
}
