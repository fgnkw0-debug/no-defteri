# Not Defteri (Offline Not Alma Uygulaması)

Kotlin + Jetpack Compose ile yazılmış, tamamen **cihaz üzerinde (offline)** çalışan bir Android not alma uygulaması. İnternet bağlantısı gerektirmez; tüm notlar Room (SQLite) ile telefonda yerel olarak saklanır.

## Özellikler
- Not ekleme, düzenleme, silme
- Başlık ve içerikte anlık arama
- Otomatik kaydetme (geri tuşuna veya onay ikonuna basınca)
- Karanlık/aydınlık tema desteği
- %100 offline — hiçbir ağ isteği yok

## Kurulum (Android Studio ile derleme)
1. [Android Studio](https://developer.android.com/studio) kur (Hedgehog / 2023.1.1 veya üzeri önerilir).
2. Bu proje klasörünü (`NotDefteri`) aç: **File > Open** ve klasörü seç.
3. Gradle senkronizasyonunun bitmesini bekle (ilk açılışta internet gerekir, sadece bağımlılıkları indirmek için).
4. Telefonunu USB ile bağla (Geliştirici Seçenekleri > USB Hata Ayıklama açık olmalı) veya bir emülatör başlat.
5. Üstteki **Run ▶** butonuna bas. Uygulama telefonuna kurulacak.

## APK oluşturmak istersen
Android Studio içinde: **Build > Build Bundle(s) / APK(s) > Build APK(s)**
Oluşan `app-debug.apk` dosyasını `app/build/outputs/apk/debug/` klasöründe bulup telefonuna kopyalayarak (ADB veya dosya transferiyle) doğrudan kurabilirsin.

## Proje yapısı
```
app/src/main/java/com/notdefteri/app/
├── data/
│   ├── Note.kt              -> Room entity (veri modeli)
│   ├── NoteDao.kt           -> Veritabanı sorguları
│   ├── NoteDatabase.kt      -> Room veritabanı (yerel SQLite)
│   └── NoteRepository.kt    -> Veri erişim katmanı
├── MainActivity.kt          -> Uygulama girişi + navigasyon
├── NoteViewModel.kt         -> UI durum yönetimi
├── NoteListScreen.kt        -> Not listesi ekranı
└── NoteEditScreen.kt        -> Not ekleme/düzenleme ekranı
```

## Notlar
- minSdk 24 (Android 7.0+) cihazlarda çalışır.
- Hiçbir internet izni tanımlı değildir; uygulama tamamen offline'dır.
